import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.awt.Canvas;
import java.io.*;
import javax.imageio.ImageIO;

public class Menu extends JFrame {
  //private JPanel JPanel;
  private Button[] buttons= new Button[4];
  private JPanel[] menus = new JPanel[3];
  public Menu(){
    setTitle("Game");
    setSize(500,500);
    menus[1]=new JPanel();//"numeri"),4);
    menus[2]=new JPanel();//"goose"),3);
    menus[0]=new JPanel();//,4);
    buttons[0]=new Button("numeri");
    buttons[0].addActionListener(e->{
      menus[1].setVisible(false);
      menus[0].setVisible(true);
      menus[0].add(buttons[1]);
    });
    buttons[1]=new Button("goose");
    buttons[1].addActionListener(e->{
      menus[0].setVisible(false);
      menus[1].setVisible(true);
    });
    buttons[2]=new Button("help");
    buttons[3]=new Button("quit");
    buttons[3].addActionListener(e->{
      //this.dispose();
      System.exit(0);
    });
    //JPanel = new JPanel("cat.jpg");
    Container content = getContentPane();
    content.setLayout(new BoxLayout(content,BoxLayout.PAGE_AXIS));
    for ( Button a : buttons) {
      menus[0].add(a);
      menus[0].add(Box.createVerticalGlue());
      menus[0].setAlignmentX(Component.CENTER_ALIGNMENT);
      menus[1].add(a);
      menus[1].add(Box.createVerticalGlue());
      menus[1].setAlignmentX(Component.CENTER_ALIGNMENT);
      /*buttons[i].setBounds(200,i*spacing,80,100);
      content.add(buttons[i]);
      content.add(Box.createRigidArea(new Dimension(0,25)));*/
    }
    menus[0].setVisible(false);
    content.add(menus[0]);
    content.add(menus[1]);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    menus[0].setBackground(Color.blue);
    menus[1].setBackground(Color.BLACK);
    setVisible(true);
    pack();
  }/*
  public void render(){
    BufferStrategy bs = getBufferStrategy();
    if(bs==null){
      createBufferStrategy(3);
      return;
    }
    Graphics g = bs.getDrawGraphics();
    g.fillRect(0,0,45,89);
    g.dispose();
    bs.show();
  }*/
  public static void main(String[] args) {
    EventQueue.invokeLater(()->{
      Menu a = new Menu();
    });
  }
    class Button extends JButton {
      public Button(String title){
        super(title);
        setContentAreaFilled(false);
        setForeground(Color.WHITE);
        setFont(new Font("Monospaced Regular",Font.ITALIC,12));
      }
    }/*
    class JPanel extends JJPanelel{
      private Button[] buttons;
      public JPanel(String name,int nbButtons){
        buttons=new Button[nbButtons];

      }
    }*/
    /*
    class JPanel extends JJPanelel{
      private BufferedImage image;
      public JPanel(String name){
        try {
          image=ImageIO.read(new File(name));
        }
        catch (Exception e) {
          e.printStackTrace();
        }
      }
      public void paintComponent(Graphics g){
        super.paintComponent(g);
        g.drawImage(image,0,0,this);
      }
    }*/
}
