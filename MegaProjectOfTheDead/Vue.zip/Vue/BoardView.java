import javax.swing.event.*;
import javax.swing.*;
import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.util.Random;
import java.io.File;
import javax.imageio.ImageIO;

public abstract class BoardView extends JPanel{
  public BoardView(){
    //setTitle(name);
    setPreferredSize(new Dimension(550,550));
    //setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  }
  public String pathCase(int i){
     if(i%9==0)return "oie.jpg";
     else if(i==6)return "pont.jpg";
     else if(i==19)return "hotel.jpg";
     else if(i==31)return "puit.jpg";
     else if(i==42)return "puzzle.png";
     else if(i==52)return "prison.jpg";
     else if(i==58)return "mort.jpg";
     else return "";
  }
  public void imgCase(String path,Graphics g,int x, int y){
    try {
      BufferedImage img = ImageIO.read(new File(path));
      g.drawImage(img,x,y,this);
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }
  public void setColorCase(int i,Graphics g){
   if(i%9==0)g.setColor(Color.RED);
   else if(i==6)g.setColor(Color.yellow);
   else if(i==19)g.setColor(Color.green);
   else if(i==31)g.setColor(Color.pink);
   else if(i==42)g.setColor(Color.lightGray);
   else if(i==52)g.setColor(Color.magenta);
   else if(i==58)g.setColor(Color.black);
   else g.setColor(Color.blue);
 }
  public void paintComponent(Graphics g){
    super.paintComponent(g);
  }
  public abstract void drawCase(Graphics g);
}
