import javax.swing.event.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class BoardViewZig extends BoardView{
  public BoardViewZig(){
    super();
  }
  public void drawCase(Graphics g){
      int x=0,y=0,a=0;
      String path="";
      for (int i = 1; i <=63 ; i++) {
        //Rectangle z = new Rectangle(x,y,25,35);
        //int centerX=(int) z.getCenterX();
        //int centerY=(int) z.getCenterY();
        //super.setColorCase(i,g);
        path=super.pathCase(i);
        if(path.equals("")){
          Rectangle z = new Rectangle(x,y,60,60);
          int centerX=(int) z.getCenterX();
          int centerY=(int) z.getCenterY();
          g.setColor(Color.BLUE);
          g.fillRect(x,y,60,60);
          g.setColor(Color.WHITE);
          g.drawString(Integer.toString(i),centerX,centerY);
        }
        else super.imgCase(path,g,x,y);
        if(a==0)x+=60;
        else if(a==1)x-=60;
        if(x/500>0){
          a=1;
          x-=60;
          y+=65;
        }
        else if(x<0){
          a=0;
          x+=60;
          y+=65;
        }
      }
  }
  public void paintComponent(Graphics g){
    super.paintComponent(g);
    drawCase(g);
  }
}
