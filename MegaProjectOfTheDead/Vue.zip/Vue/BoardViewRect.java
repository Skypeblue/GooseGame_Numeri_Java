import javax.swing.event.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class BoardViewRect extends BoardView{
  public BoardViewRect(){
    super();
  }
  public void drawCase(Graphics g){
      int x=0,y=0;
      String path="";
      for (int i = 1; i <=63 ; i++) {
        path=super.pathCase(i);
        if(!path.equals("")){
          super.imgCase(path,g,x,y);//g.fillRect(x,y,200,200);
        }
        else {
          Rectangle z = new Rectangle(x,y,55,55);
          int centerX=(int) z.getCenterX();
          int centerY=(int) z.getCenterY();
          g.setColor(Color.BLUE);
          g.fillRect(x,y,60,60);
          g.setColor(Color.WHITE);
          g.drawString(Integer.toString(i),centerX,centerY);
        }
        x+=60;
        if(x/500>0){
          x=0;
          y+=65;
        }
      }
  }
  public void paintComponent(Graphics g){
    super.paintComponent(g);
    drawCase(g);
/*    int alea_1=rand.nextInt(6)+1;
    int alea_2=rand.nextInt(6)+1;
    g.setColor(Color.BLACK);
    g.drawString(Integer.toString(alea_1),400,400);
    g.drawString(Integer.toString(alea_2),420,400);*/
  }
}
