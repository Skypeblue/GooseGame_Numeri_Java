import javax.swing.event.*;
import javax.swing.*;
import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.util.Random;
import java.io.File;
import javax.imageio.ImageIO;

public class BoardMain extends JFrame{
  static Random rand = new Random();
  private BoardView view;
  private JButton roll,nextTurn;
  private JMenuBar menu;
  private JMenuItem help,exit;

  public BoardMain(String name){
    setTitle(name);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setPreferredSize(new Dimension(1000,1000));
    JButton roll = new JButton("Play");
    Container content = getContentPane();
    content.setLayout(new FlowLayout());
    content.add(roll);
    roll.addActionListener(e->{
      this.throwDiceG();
    });
    JButton nextTurn= new JButton("nextTurn");
    nextTurn.addActionListener(e->{
      view.repaint();
    });
    content.add(nextTurn);
    menu= new JMenuBar();
    setJMenuBar(menu);
    help = new JMenuItem("help");
    exit = new JMenuItem("exit");
    exit.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Q,InputEvent.CTRL_MASK));
    exit.addActionListener(e->{
      this.dispose();
    });
    menu.add(help);
    menu.add(exit);
  }
  public void setView(BoardView c){
    view=c;
    getContentPane().add(view);
  }
  public void throwDiceG(){
    String alea_1=Integer.toString(rand.nextInt(6)+1);
    String alea_2=Integer.toString(rand.nextInt(6)+1);
    Graphics g = this.getGraphics();
    try {
      BufferedImage im_1 = ImageIO.read(new File("face"+alea_1+".png"));
      BufferedImage im_2 = ImageIO.read(new File("face"+alea_2+".png"));
      g.drawImage(im_1,0,450,this);
      g.drawImage(im_2,100,450,this);
    }
    catch(Exception e){
      e.printStackTrace();
    }
    g.dispose();
  }
}
