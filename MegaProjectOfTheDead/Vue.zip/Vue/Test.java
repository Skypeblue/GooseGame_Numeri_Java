import javax.swing.event.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Test{
    public static void main(String[] args) {
      EventQueue.invokeLater(()->{
        BoardMain a = new BoardMain("Rect");
        BoardViewCol c = new BoardViewCol();
        c.setPreferredSize(new Dimension(1000,4000));
        JScrollPane scroll= new JScrollPane(c);
        scroll.setBorder(null);
        a.add(scroll);
        a.setVisible(true);
        a.pack();
      });
    }
}
