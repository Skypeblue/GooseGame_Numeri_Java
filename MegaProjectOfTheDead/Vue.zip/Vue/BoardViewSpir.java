import javax.swing.event.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class BoardViewSpir extends BoardView{
  public BoardViewSpir(){
    super();
  }
  public void drawCase(Graphics g){
      int height=this.getHeight();
      int width=this.getWidth();
      Rectangle whole = new Rectangle(0,0,width-10,height-10);
      int x=(int) whole.getCenterX();
      int y=(int) whole.getCenterY();
      int loop=0,stepInLoop=1,stepOutLoop=1,idCase=63,direc=0;
      String path="";
      while(idCase!=0){
        while(loop!=2 && idCase!=0){
          stepInLoop=stepOutLoop;
          while(stepInLoop!=0 && idCase!=0){
            //Rectangle z = new Rectangle(x,y,25,35);
            //int centerX=(int) z.getCenterX();
            //int centerY=(int) z.getCenterY();
            //super.setColorCase(idCase,g);
            path=super.pathCase(idCase);
            if(path.equals("")){
              Rectangle z = new Rectangle(x,y,55,55);
              int centerX=(int) z.getCenterX();
              int centerY=(int) z.getCenterY();
              g.setColor(Color.BLUE);
              g.fillRect(x,y,60,60);
              g.setColor(Color.WHITE);
              g.drawString(Integer.toString(idCase),centerX,centerY);
            }
            else{
              super.imgCase(path,g,x,y);
            }
          //  g.setColor(Color.WHITE);
      //      g.drawString(Integer.toString(idCase),centerX,centerY);
            if(direc==0)x+=55;
            else if(direc==1)y-=65;
            else if(direc==2)x-=55;
            else y+=65;
            stepInLoop--;
            idCase--;
          }
          direc++;
          direc%=4;
          loop++;
        }
        stepOutLoop++;
        loop=0;
      }
  }
  public void paintComponent(Graphics g){
    super.paintComponent(g);
    drawCase(g);
  }
}
