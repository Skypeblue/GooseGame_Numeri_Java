import javax.swing.event.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class BoardViewCol extends BoardView{
  //private JScrollPane scroll;
  public BoardViewCol(){
    super();
    //setPreferredSize(new Dimension(400,4000));
    //scroll= new JScrollPane(this);
    //scroll.setViewportView(this);
    //this.getParent().add(scroll);
  }
  public void drawCase(Graphics g){
      int x=0,y=0;
      String path="";
      Rectangle whole = new Rectangle(0,0,this.getWidth(),this.getHeight());
      x = (int) whole.getCenterX();
      for (int i = 1; i <=63 ; i++) {
        path=super.pathCase(i);
        if(path.equals("")){
          Rectangle z = new Rectangle(x,y,55,55);
          int centerX = (int) z.getCenterX();
          int centerY = (int) z.getCenterY();
          g.setColor(Color.BLUE);
          g.fillRect(x,y,60,60);
          g.setColor(Color.WHITE);
          g.drawString(Integer.toString(i),centerX,centerY);
        }
        else imgCase(path,g,x,y);
        y+=60;
      }
  }
  public void paintComponent(Graphics g){
    super.paintComponent(g);
    drawCase(g);
  }
}
